# O código abaixo tenta verificar se a idade de uma pessoa é maior que 18. Há um erro lógico na comparação.

# Dica: teste com valores entre 16 e 21 anos ;)

idade = int(input("Digite sua idade: "))

if idade > 18:
    print("Você é maior de idade.")
else:
    print("Você é menor de idade.")