# O código abaixo tenta somar dois números, mas está com um erro ao tentar somá-loss.

num1 = input("Digite o primeiro número: ")
num2 = input("Digite o segundo número: ")

resultado = num1+num2
print("A soma é:", resultado)