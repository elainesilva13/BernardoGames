# Enunciado: O código abaixo deve verificar se um número inserido é positivo ou negativo, mas há um erro de comparação.

num = int(input("Digite um número: "))

if num >= 0:
    print("Número positivo ou zero")
else:
    print("Número negativo")