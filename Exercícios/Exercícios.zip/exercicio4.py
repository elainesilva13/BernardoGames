# Corrija o código

valores = []

for i in range(3):
    valor = input("Digite um número: ")
    valores.append(valor * 2)

    print(valores)

    